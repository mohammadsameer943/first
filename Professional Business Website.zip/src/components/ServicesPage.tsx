import { motion } from 'motion/react';
import { Palette, Monitor, Smartphone, Package, TrendingUp, Mail, ArrowRight, CheckCircle } from 'lucide-react';

interface ServicesPageProps {
  onNavigate: (page: string) => void;
}

export function ServicesPage({ onNavigate }: ServicesPageProps) {
  const services = [
    {
      icon: Palette,
      title: 'Graphic Design',
      description: 'Create stunning visual content that captures attention and communicates your message effectively.',
      features: [
        'Logo Design & Branding',
        'Marketing Materials',
        'Print Design',
        'Illustrations & Icons',
        'Infographics',
        'Social Media Graphics',
      ],
      color: 'from-purple-500 to-pink-500',
    },
    {
      icon: Monitor,
      title: 'Web Design & Development',
      description: 'Build modern, responsive websites that deliver exceptional user experiences and drive conversions.',
      features: [
        'Custom Website Design',
        'Responsive Development',
        'E-Commerce Solutions',
        'CMS Integration',
        'Website Maintenance',
        'Performance Optimization',
      ],
      color: 'from-blue-500 to-cyan-500',
    },
    {
      icon: Smartphone,
      title: 'UI/UX Design',
      description: 'Design intuitive and engaging interfaces that users love with a focus on usability and aesthetics.',
      features: [
        'User Research & Testing',
        'Wireframing & Prototyping',
        'Mobile App Design',
        'Interface Design',
        'User Flow Optimization',
        'Design Systems',
      ],
      color: 'from-green-500 to-emerald-500',
    },
    {
      icon: Package,
      title: 'Brand Identity',
      description: 'Develop comprehensive brand identities that make your business memorable and distinctive.',
      features: [
        'Brand Strategy',
        'Visual Identity',
        'Brand Guidelines',
        'Business Card Design',
        'Stationery Design',
        'Brand Collateral',
      ],
      color: 'from-orange-500 to-red-500',
    },
    {
      icon: TrendingUp,
      title: 'Digital Marketing Design',
      description: 'Create compelling marketing materials that boost engagement and drive business growth.',
      features: [
        'Social Media Campaigns',
        'Email Templates',
        'Banner Ads',
        'Landing Pages',
        'Marketing Collateral',
        'Presentation Design',
      ],
      color: 'from-indigo-500 to-purple-500',
    },
    {
      icon: Mail,
      title: 'Print Design',
      description: 'Design high-quality print materials that make a lasting impression on your audience.',
      features: [
        'Brochures & Flyers',
        'Posters & Banners',
        'Packaging Design',
        'Magazine Layouts',
        'Annual Reports',
        'Promotional Materials',
      ],
      color: 'from-pink-500 to-rose-500',
    },
  ];

  const process = [
    {
      step: '01',
      title: 'Discovery',
      description: 'We start by understanding your business, goals, and target audience.',
    },
    {
      step: '02',
      title: 'Strategy',
      description: 'We develop a comprehensive strategy tailored to your specific needs.',
    },
    {
      step: '03',
      title: 'Design',
      description: 'Our team creates stunning designs that bring your vision to life.',
    },
    {
      step: '04',
      title: 'Development',
      description: 'We build and develop your project with attention to every detail.',
    },
    {
      step: '05',
      title: 'Launch',
      description: 'We deploy your project and ensure everything runs smoothly.',
    },
    {
      step: '06',
      title: 'Support',
      description: 'We provide ongoing support and maintenance for your success.',
    },
  ];

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-gray-900 mb-6">Our Services</h1>
            <p className="text-gray-600 text-lg">
              Comprehensive design solutions tailored to elevate your brand and drive business growth.
              From concept to completion, we deliver excellence at every step.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-2xl border border-gray-200 p-8 hover:shadow-xl transition-all hover:border-transparent"
                >
                  <div className={`inline-flex p-4 rounded-xl bg-gradient-to-r ${service.color} mb-6`}>
                    <Icon className="text-white" size={32} />
                  </div>
                  
                  <h3 className="text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-600 mb-6">{service.description}</p>

                  <div className="space-y-3">
                    {service.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center gap-2">
                        <CheckCircle className="text-green-500 flex-shrink-0" size={18} />
                        <span className="text-gray-700 text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-gray-900 mb-4">Our Process</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We follow a proven process to ensure your project is delivered on time and exceeds expectations
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {process.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="relative"
              >
                <div className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-lg transition-shadow">
                  <div className="text-5xl bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent mb-4 opacity-20">
                    {item.step}
                  </div>
                  <h3 className="text-gray-900 mb-3">{item.title}</h3>
                  <p className="text-gray-600 text-sm">{item.description}</p>
                </div>
                {index < process.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                    <ArrowRight className="text-gray-300" size={24} />
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Philosophy */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-gray-900 mb-6">Flexible Pricing, Fixed Quality</h2>
              <p className="text-gray-600 mb-6">
                We believe in transparent pricing that fits your budget. Whether you're a startup or an established business,
                we have solutions tailored to your needs.
              </p>
              
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <CheckCircle className="text-green-500 flex-shrink-0 mt-0.5" size={20} />
                  <div>
                    <h4 className="text-gray-900 mb-1">No Hidden Fees</h4>
                    <p className="text-gray-600 text-sm">Clear, upfront pricing with no surprises</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="text-green-500 flex-shrink-0 mt-0.5" size={20} />
                  <div>
                    <h4 className="text-gray-900 mb-1">Custom Packages</h4>
                    <p className="text-gray-600 text-sm">Tailored solutions based on your specific requirements</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="text-green-500 flex-shrink-0 mt-0.5" size={20} />
                  <div>
                    <h4 className="text-gray-900 mb-1">Value for Money</h4>
                    <p className="text-gray-600 text-sm">Premium quality at competitive prices</p>
                  </div>
                </div>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-gradient-to-br from-purple-50 to-blue-50 p-8 rounded-2xl"
            >
              <h3 className="text-gray-900 mb-6">Get a Custom Quote</h3>
              <p className="text-gray-600 mb-6">
                Tell us about your project and we'll provide a detailed quote within 24 hours.
              </p>
              
              <div className="space-y-4 mb-6">
                <div className="bg-white p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-900">Starter Package</span>
                    <span className="text-gray-900">From $999</span>
                  </div>
                  <p className="text-gray-600 text-sm">Perfect for small businesses and startups</p>
                </div>
                <div className="bg-white p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-900">Professional Package</span>
                    <span className="text-gray-900">From $2,499</span>
                  </div>
                  <p className="text-gray-600 text-sm">Ideal for growing businesses</p>
                </div>
                <div className="bg-white p-4 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-gray-900">Enterprise Package</span>
                    <span className="text-gray-900">Custom</span>
                  </div>
                  <p className="text-gray-600 text-sm">Comprehensive solutions for large organizations</p>
                </div>
              </div>

              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => onNavigate('contact')}
                className="w-full px-6 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl hover:shadow-xl transition-shadow flex items-center justify-center gap-2"
              >
                Request a Quote
                <ArrowRight size={20} />
              </motion.button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <h2 className="text-white">Ready to Get Started?</h2>
            <p className="text-purple-100 max-w-2xl mx-auto text-lg">
              Let's discuss your project and create something amazing together
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onNavigate('contact')}
              className="px-8 py-4 bg-white text-purple-600 rounded-xl hover:shadow-xl transition-shadow inline-flex items-center gap-2"
            >
              Contact Us Today
              <ArrowRight size={20} />
            </motion.button>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
