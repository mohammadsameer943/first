import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink, X } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface PortfolioPageProps {
  onNavigate: (page: string) => void;
}

export function PortfolioPage({ onNavigate }: PortfolioPageProps) {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedProject, setSelectedProject] = useState<number | null>(null);

  const categories = [
    { id: 'all', name: 'All Projects' },
    { id: 'web', name: 'Web Design' },
    { id: 'graphic', name: 'Graphic Design' },
    { id: 'branding', name: 'Branding' },
    { id: 'uiux', name: 'UI/UX' },
  ];

  const projects = [
    {
      id: 1,
      title: 'Modern E-Commerce Platform',
      category: 'web',
      description: 'A sleek and modern e-commerce platform with seamless user experience and high conversion rates.',
      client: 'TechStore Inc.',
      year: '2024',
      tags: ['Web Design', 'E-Commerce', 'UI/UX'],
      image: 'https://images.unsplash.com/photo-1603985585179-3d71c35a537c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWIlMjBkZXNpZ24lMjB3b3Jrc3BhY2V8ZW58MXx8fHwxNzYzOTk0MzgwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: 2,
      title: 'Corporate Brand Identity',
      category: 'branding',
      description: 'Complete brand identity system including logo, color palette, and brand guidelines.',
      client: 'Global Finance Co.',
      year: '2024',
      tags: ['Branding', 'Logo Design', 'Brand Guidelines'],
      image: 'https://images.unsplash.com/photo-1483058712412-4245e9b90334?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmFwaGljJTIwZGVzaWduJTIwc3R1ZGlvfGVufDF8fHx8MTc2NDAxMzgzNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: 3,
      title: 'Mobile App Design',
      category: 'uiux',
      description: 'Intuitive mobile app design focusing on user engagement and seamless navigation.',
      client: 'FitLife App',
      year: '2024',
      tags: ['UI/UX', 'Mobile Design', 'App Design'],
      image: 'https://images.unsplash.com/photo-1683818051102-dd1199d163b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwZGVzaWduJTIwcG9ydGZvbGlvfGVufDF8fHx8MTc2NDAwMzgyN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: 4,
      title: 'Marketing Campaign Design',
      category: 'graphic',
      description: 'Eye-catching marketing materials for a product launch campaign.',
      client: 'StartUp Ventures',
      year: '2023',
      tags: ['Graphic Design', 'Marketing', 'Print Design'],
      image: 'https://images.unsplash.com/photo-1718220268527-4477fd170775?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBvZmZpY2UlMjBjcmVhdGl2ZSUyMGRlc2lnbnxlbnwxfHx8fDE3NjQwNzE3NDR8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: 5,
      title: 'Restaurant Website Redesign',
      category: 'web',
      description: 'Modern website redesign with online ordering and reservation system.',
      client: 'Gourmet Bistro',
      year: '2023',
      tags: ['Web Design', 'Responsive', 'UX Design'],
      image: 'https://images.unsplash.com/photo-1587522384446-64daf3e2689a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaW5pbWFsaXN0JTIwd29ya3NwYWNlfGVufDF8fHx8MTc2Mzk3MjI5MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: 6,
      title: 'Fashion Brand Identity',
      category: 'branding',
      description: 'Luxurious brand identity for a premium fashion label.',
      client: 'Elegance Fashion',
      year: '2023',
      tags: ['Branding', 'Fashion', 'Luxury Design'],
      image: 'https://images.unsplash.com/photo-1700561570982-5f845601c505?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMHRlYW0lMjBtZWV0aW5nfGVufDF8fHx8MTc2NDAxOTM1OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: 7,
      title: 'SaaS Dashboard Design',
      category: 'uiux',
      description: 'Clean and intuitive dashboard design for a B2B SaaS platform.',
      client: 'DataFlow Systems',
      year: '2023',
      tags: ['UI/UX', 'Dashboard', 'SaaS'],
      image: 'https://images.unsplash.com/photo-1603985585179-3d71c35a537c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3ZWIlMjBkZXNpZ24lMjB3b3Jrc3BhY2V8ZW58MXx8fHwxNzYzOTk0MzgwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: 8,
      title: 'Social Media Graphics Package',
      category: 'graphic',
      description: 'Comprehensive social media graphics suite for consistent brand presence.',
      client: 'Influence Media',
      year: '2023',
      tags: ['Graphic Design', 'Social Media', 'Digital Marketing'],
      image: 'https://images.unsplash.com/photo-1483058712412-4245e9b90334?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmFwaGljJTIwZGVzaWduJTIwc3R1ZGlvfGVufDF8fHx8MTc2NDAxMzgzNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: 9,
      title: 'Real Estate Portal',
      category: 'web',
      description: 'Feature-rich real estate platform with advanced search and filtering.',
      client: 'PropertyHub',
      year: '2023',
      tags: ['Web Design', 'Real Estate', 'Portal'],
      image: 'https://images.unsplash.com/photo-1683818051102-dd1199d163b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwZGVzaWduJTIwcG9ydGZvbGlvfGVufDF8fHx8MTc2NDAwMzgyN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
  ];

  const filteredProjects = selectedCategory === 'all' 
    ? projects 
    : projects.filter(p => p.category === selectedCategory);

  return (
    <div className="min-h-screen pt-20">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-3xl mx-auto"
          >
            <h1 className="text-gray-900 mb-6">Our Portfolio</h1>
            <p className="text-gray-600 text-lg">
              Explore our collection of successful projects that showcase our creativity, expertise, and commitment to excellence.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-12 bg-white sticky top-20 z-40 border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <motion.button
                key={category.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-6 py-2 rounded-full transition-all ${
                  selectedCategory === category.id
                    ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                {category.name}
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            layout
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            <AnimatePresence mode="popLayout">
              {filteredProjects.map((project, index) => (
                <motion.div
                  key={project.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ y: -10 }}
                  onClick={() => setSelectedProject(project.id)}
                  className="group cursor-pointer"
                >
                  <div className="relative overflow-hidden rounded-2xl shadow-lg">
                    <ImageWithFallback
                      src={project.image}
                      alt={project.title}
                      className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
                      <h3 className="text-white mb-2">{project.title}</h3>
                      <p className="text-gray-300 text-sm mb-3">{project.description}</p>
                      <div className="flex items-center gap-2">
                        <ExternalLink className="text-white" size={20} />
                        <span className="text-white text-sm">View Details</span>
                      </div>
                    </div>
                  </div>
                  <div className="mt-4">
                    <h3 className="text-gray-900 mb-2">{project.title}</h3>
                    <div className="flex flex-wrap gap-2">
                      {project.tags.slice(0, 2).map((tag, idx) => (
                        <span key={idx} className="text-xs px-3 py-1 bg-purple-50 text-purple-600 rounded-full">
                          {tag}
                        </span>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </div>
      </section>

      {/* Project Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSelectedProject(null)}
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            >
              {(() => {
                const project = projects.find(p => p.id === selectedProject);
                if (!project) return null;
                
                return (
                  <>
                    <div className="relative">
                      <ImageWithFallback
                        src={project.image}
                        alt={project.title}
                        className="w-full h-96 object-cover"
                      />
                      <button
                        onClick={() => setSelectedProject(null)}
                        className="absolute top-4 right-4 p-2 bg-white rounded-full hover:bg-gray-100 transition-colors"
                      >
                        <X size={24} />
                      </button>
                    </div>
                    
                    <div className="p-8">
                      <h2 className="text-gray-900 mb-4">{project.title}</h2>
                      <p className="text-gray-600 mb-6">{project.description}</p>
                      
                      <div className="grid grid-cols-2 gap-6 mb-6">
                        <div>
                          <h4 className="text-gray-900 mb-2">Client</h4>
                          <p className="text-gray-600">{project.client}</p>
                        </div>
                        <div>
                          <h4 className="text-gray-900 mb-2">Year</h4>
                          <p className="text-gray-600">{project.year}</p>
                        </div>
                      </div>
                      
                      <div className="mb-6">
                        <h4 className="text-gray-900 mb-3">Tags</h4>
                        <div className="flex flex-wrap gap-2">
                          {project.tags.map((tag, idx) => (
                            <span key={idx} className="px-4 py-2 bg-purple-50 text-purple-600 rounded-lg">
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => {
                          setSelectedProject(null);
                          onNavigate('contact');
                        }}
                        className="w-full px-6 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-xl hover:shadow-xl transition-shadow"
                      >
                        Start a Similar Project
                      </motion.button>
                    </div>
                  </>
                );
              })()}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-purple-600 to-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <h2 className="text-white">Like What You See?</h2>
            <p className="text-purple-100 max-w-2xl mx-auto text-lg">
              Let's create something amazing for your business. Get in touch to discuss your project.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => onNavigate('contact')}
              className="px-8 py-4 bg-white text-purple-600 rounded-xl hover:shadow-xl transition-shadow"
            >
              Start Your Project
            </motion.button>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
